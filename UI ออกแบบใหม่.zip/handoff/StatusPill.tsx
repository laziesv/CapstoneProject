import type { ReactNode } from "react";

export type StatusKind =
  | "verified"   // ยืนยันแล้ว / ลายน้ำตรงกัน
  | "pending"    // รอยืนยัน / รอบันทึก
  | "mismatch"   // ลายน้ำไม่ตรง / ปฏิเสธ
  | "checking"   // กำลังตรวจ
  | "suspended"; // ระงับ / ปิดคดี

const styles: Record<StatusKind, { label: string; cls: string; dot: string }> = {
  verified:  { label: "ยืนยันแล้ว", cls: "bg-success-light text-success", dot: "bg-success" },
  pending:   { label: "รอยืนยัน",  cls: "bg-warning-light text-warning", dot: "bg-warning-dot" },
  mismatch:  { label: "ลายน้ำไม่ตรง", cls: "bg-danger-light text-danger", dot: "bg-danger" },
  checking:  { label: "กำลังตรวจ", cls: "bg-primary-light text-primary", dot: "bg-primary" },
  suspended: { label: "ระงับ",     cls: "bg-surface-hover text-text-secondary", dot: "bg-muted" },
};

/** ป้ายสถานะเดียวของทั้งระบบ — สีและข้อความมาจากที่นี่ที่เดียว */
export default function StatusPill({
  kind,
  label,
  dot = true,
  icon,
}: {
  kind: StatusKind;
  label?: ReactNode;
  dot?: boolean;
  icon?: ReactNode;
}) {
  const s = styles[kind];
  return (
    <span
      className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-[5px] text-xs font-semibold ${s.cls}`}
    >
      {icon ?? (dot && <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />)}
      {label ?? s.label}
    </span>
  );
}
