"use client";
import { usePathname } from "next/navigation";
import { Bell, Search } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

const titles: Record<string, string> = {
  "/dashboard": "แดชบอร์ด",
  "/cases": "คดี",
  "/verify": "ตรวจสอบลายน้ำ",
  "/logs": "บันทึกการเข้าถึง",
  "/users": "จัดการผู้ใช้",
  "/profile": "โปรไฟล์",
};

export default function TopBar() {
  const pathname = usePathname();
  const { user } = useAuth();

  const displayName = user?.full_name || user?.username || "ผู้ใช้งาน";
  const key = Object.keys(titles).find((k) => pathname.startsWith(k));
  const title = key ? titles[key] : "DEVA";

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-5 border-b border-border bg-surface px-7">
      <span className="text-base font-semibold">{title}</span>

      {/* ค้นหา — pill สีเทา ไม่มีขอบ */}
      <div className="relative flex-1 max-w-[420px]">
        <Search className="absolute left-[18px] top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
        <input
          type="text"
          placeholder="ค้นหาหมายเลขหลักฐาน คดี หรือแฮช"
          className="h-10 w-full rounded-full bg-surface-hover pl-11 pr-16 text-sm outline-none placeholder:text-muted focus:ring-2 focus:ring-primary/25"
        />
        <kbd className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 rounded-md bg-surface px-1.5 py-0.5 font-mono text-[11px] text-muted">
          ⌘K
        </kbd>
      </div>

      <div className="ml-auto flex items-center gap-3">
        {/* สถานะโหนดบล็อกเชน — ความน่าเชื่อถือของระบบ เห็นได้ทุกหน้า */}
        <span className="hidden items-center gap-2 rounded-full border border-border px-3.5 py-2 text-[13px] font-medium lg:flex">
          <span className="h-[7px] w-[7px] rounded-full bg-success" />
          โหนดบล็อกเชนออนไลน์
        </span>
        <button
          aria-label="การแจ้งเตือน"
          className="relative flex h-9 w-9 items-center justify-center rounded-full bg-surface-hover transition-colors hover:bg-border"
        >
          <Bell className="h-[17px] w-[17px]" />
          <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-danger ring-2 ring-surface" />
        </button>
        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-ink text-[13px] font-semibold text-white">
          {displayName.charAt(0)}
        </span>
      </div>
    </header>
  );
}
