# นำดีไซน์ 1b ไปใช้จริง — 5 ขั้น

ไฟล์ในโฟลเดอร์นี้พร้อมก็อปวางทับของเดิม (path ตรงตามโครงโปรเจกต์)

| ก็อปไฟล์นี้ | ไปวางที่ |
| --- | --- |
| `globals-theme.css` | วางแทน **บล็อก `@theme inline { … }` + `body { … }` + scrollbar** ที่หัวไฟล์ `src/app/globals.css` (บรรทัด 1–37) — ส่วน `.login-page` และที่เหลือด้านล่างเก็บไว้ก่อน |
| `Sidebar.tsx` | `src/components/layout/Sidebar.tsx` |
| `TopBar.tsx` | `src/components/layout/TopBar.tsx` |
| `StatusPill.tsx` | `src/components/ui/StatusPill.tsx` (สร้างโฟลเดอร์ `ui` ใหม่) |
| `StatBand.tsx` | `src/components/ui/StatBand.tsx` |
| `layout.tsx` | `src/app/(protected)/layout.tsx` |

## 1. ฟอนต์ Sarabun
ใน `src/app/layout.tsx` (root) เพิ่ม:

```tsx
import { Sarabun, IBM_Plex_Mono } from "next/font/google";

const sarabun = Sarabun({ subsets: ["thai", "latin"], weight: ["400","500","600","700"], variable: "--font-sans" });
const mono = IBM_Plex_Mono({ subsets: ["latin"], weight: ["400","500"], variable: "--font-mono" });
```

แล้วใส่ `className={\`${sarabun.variable} ${mono.variable}\`}` ที่ `<html>` (ลบ Geist ออก)

## 2. token + layout
ก็อป `globals-theme.css` และ `layout.tsx` ตามตารางข้างบน (`pl-60` → `pl-[76px]`, `p-6` → `p-7`)

## 3. Sidebar + TopBar
ก็อปทับ 2 ไฟล์ — ได้รางไอคอนดำ 76px + top bar ขาว 64px ทันที ทุกหน้าเปลี่ยนตาม

## 4. 3 กฎที่ทำให้หน้าที่เหลือเข้าชุดกันเอง
ค้นหา-แทนที่ทั่วโปรเจกต์:

- ปุ่ม/ป้าย/ช่องค้นหา: `rounded-lg` → `rounded-full`
- การ์ด: `rounded-xl border border-border shadow-sm` → `rounded-2xl border border-border` (ตัด `shadow-sm` / `hover:shadow-md` ออกให้หมด)
- ตัวเลข เลขคดี แฮช IP เวลา: เติม `font-mono`

## 5. แทนป้ายสถานะด้วย StatusPill
ทุกที่ที่เขียนป้ายสถานะเองด้วย `bg-success-light text-success` ฯลฯ เปลี่ยนเป็น:

```tsx
<StatusPill kind="verified" />           // ยืนยันแล้ว
<StatusPill kind="pending" />            // รอยืนยัน
<StatusPill kind="mismatch" />           // ลายน้ำไม่ตรง
<StatusPill kind="suspended" />          // ระงับ
<StatusPill kind="verified" label="ลายน้ำตรงกัน" />   // เปลี่ยนข้อความได้
```

และแถบ KPI ดำบนแดชบอร์ด:

```tsx
<StatBand items={[
  { label: "หลักฐานทั้งหมด", value: "1,284", hint: "+38 ในสัปดาห์นี้", tone: "success" },
  { label: "คดีที่ดำเนินอยู่", value: 24, hint: "จาก 61 คดีทั้งหมด" },
  { label: "ยืนยันบนบล็อกเชนแล้ว", value: "1,271", hint: "รอยืนยัน 13 ชิ้น", valueTone: "success", tone: "warning" },
  { label: "ธุรกรรมบล็อกเชน", value: "3,902", hint: "บล็อกล่าสุด #874,193" },
]} />
```

> ทำถึงข้อ 3 ก็เห็นผลเกือบทั้งระบบแล้ว — ข้อ 4–5 คือเก็บรายละเอียดหน้าต่อหน้า
